using Pkg
Pkg.add("PyPlot")
Pkg.add("LinearAlgebra")
Pkg.add("LoopVectorization")
Pkg.add("DifferentialEquations")
Pkg.add("ArgParse")
Pkg.add("HDF5")

